"""Auto Organizer utilities."""
